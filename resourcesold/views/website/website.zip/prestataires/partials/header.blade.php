<header class="navbar navbar-dark sticky-top bg-danger flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="{{ route('home')}}"><img
            src="{{ asset('assets/front/images/resources/logo.png') }}" alt="Awesome Logo" width="100px"
            class="logo-header">
        <style>
            .logo-header {
                height: 45px;
            }

        </style>
    </a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse"
        data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="navbar-nav">
        <div class="nav-item text-nowrap">
            <a class="nav-link px-3" href="#">{{ Auth()->user()->last_name }}
                {{ Auth()->user()->first_name }}</a>
        </div>
    </div>
</header>
